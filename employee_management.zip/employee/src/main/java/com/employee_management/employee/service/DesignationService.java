package com.employee_management.employee.service;

import org.springframework.stereotype.Service;

@Service
public class DesignationService {


}
